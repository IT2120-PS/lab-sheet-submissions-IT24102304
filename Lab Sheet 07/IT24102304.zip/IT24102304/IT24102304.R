setwd("C:\\Users\\IT24102304\\Desktop\\IT24102304")
#Question 1
1-punif(10,min=0,max=40,lower.tail=TRUE)-punif(25,min=0,max=40,lower.tail=FALSE)

#Question 2
pexp(2,rate=0.3333333,lower.tail=TRUE)

#Question 3
pnorm(131,mean=100,sd=15,lower.tail=FALSE)
qnorm(0.95,mean=100,sd=15,lower.tail=TRUE)